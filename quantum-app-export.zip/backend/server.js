// server.js — Quantum Learning App Backend
// Node.js + Express + MongoDB

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// ─── MongoDB Connection ───────────────────────────────────────────────────────
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/quantum_app';
mongoose.connect(MONGO_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.log('⚠️  MongoDB not connected (demo mode):', err.message));

// ─── Schemas ──────────────────────────────────────────────────────────────────

// Tracks which topics a user has completed
const progressSchema = new mongoose.Schema({
  username: { type: String, required: true },
  topic: { type: String, required: true },   // 'qubit', 'bloch', 'circuit'
  completed: { type: Boolean, default: false },
  completedAt: { type: Date, default: Date.now }
});

// Stores quiz attempts and scores
const quizSchema = new mongoose.Schema({
  username: { type: String, required: true },
  topic: { type: String, required: true },
  score: { type: Number, required: true },
  total: { type: Number, required: true },
  answers: [{ question: String, selected: String, correct: Boolean }],
  attemptedAt: { type: Date, default: Date.now }
});

const Progress = mongoose.model('Progress', progressSchema);
const Quiz     = mongoose.model('Quiz', quizSchema);

// ─── Progress Routes ──────────────────────────────────────────────────────────

// GET all progress for a user
app.get('/api/progress/:username', async (req, res) => {
  try {
    const records = await Progress.find({ username: req.params.username });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST mark a topic complete
app.post('/api/progress', async (req, res) => {
  try {
    const { username, topic } = req.body;
    // Upsert: update if exists, create if not
    const record = await Progress.findOneAndUpdate(
      { username, topic },
      { completed: true, completedAt: new Date() },
      { upsert: true, new: true }
    );
    res.status(201).json(record);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ─── Quiz Routes ──────────────────────────────────────────────────────────────

// GET all quiz results for a user
app.get('/api/quiz/:username', async (req, res) => {
  try {
    const results = await Quiz.find({ username: req.params.username }).sort({ attemptedAt: -1 });
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST save a quiz result
app.post('/api/quiz', async (req, res) => {
  try {
    const quiz = new Quiz(req.body);
    await quiz.save();
    res.status(201).json(quiz);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GET leaderboard — top scores across all users
app.get('/api/leaderboard', async (req, res) => {
  try {
    const results = await Quiz.aggregate([
      { $group: { _id: '$username', bestScore: { $max: '$score' }, attempts: { $sum: 1 } } },
      { $sort: { bestScore: -1 } },
      { $limit: 10 }
    ]);
    res.json(results);
  } catch {
    res.json([{ _id: 'Alice', bestScore: 3, attempts: 2 }, { _id: 'Bob', bestScore: 2, attempts: 1 }]);
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', db: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`⚛️  Quantum backend running on http://localhost:${PORT}`));
